    <?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="col-md-12">
            <h1>Blogs</h1>
            <p><?php echo e(Session::get('alert-success')); ?></p>
        </div>
    </div>
    <div class="row">
        <table class="table table-striped">
            <tr>
                <th>No. </th>
                <th>Title </th>
                <th>Description </th>
                <th>Actions</th>
            </tr>

            <a href="<?php echo e(route('blog.create')); ?>" class="btn btn-info pull-right">Inserir Registro</a>
            <?php $no=1; ?>

            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($blog->title); ?></td>
                    <td><?php echo e($blog->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('blog.edit',$blog->id)); ?>" ><button><span class="glyphicon glyphicon-refresh"></span></button></a>

                        <form action="<?php echo e(route('blog.destroy',$blog->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="delete">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            
                            <button type="submit"  value="apagar"><span class="glyphicon glyphicon-trash"></span></button>

                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo $blogs->links(); ?>

    </div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>