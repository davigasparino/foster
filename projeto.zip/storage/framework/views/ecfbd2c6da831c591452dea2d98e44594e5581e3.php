    <?php $__env->startSection('content'); ?>
    <?php echo e(Session::get('alert-success')); ?>

    <div class="col-md-12">
        <div class="col-md-12">
            <h1>Products</h1>
        </div>
    </div>
    <div class="row">
        <table class="table table-striped">
            <tr>
                <th>No. </th>
                <th>Title </th>
                <th>Description </th>
                <th>Actions</th>
            </tr>

            <a href="<?php echo e(route('product.create')); ?>" class="btn btn-info pull-right">Inserir Registro</a>
            <?php $no=1; ?>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo e($product->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('product.edit',$product->id)); ?>" ><button><span class="glyphicon glyphicon-refresh"></span></button></a>

                        <form action="<?php echo e(route('product.destroy',$product->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="delete">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            
                            <button type="submit"  value="apagar"><span class="glyphicon glyphicon-trash"></span></button>

                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo $products->links(); ?>

    </div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>