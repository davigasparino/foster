@extends('master')
    @section('content')
    <div class="col-md-12">
        <div class="col-md-12">
            <h1>Blogs</h1>
            <p>{{ Session::get('alert-success') }}</p>
        </div>
    </div>
    <div class="row">
        <table class="table table-striped">
            <tr>
                <th>No. </th>
                <th>Title </th>
                <th>Description </th>
                <th>Actions</th>
            </tr>

            <a href="{{route('blog.create')}}" class="btn btn-info pull-right">Inserir Registro</a>
            <?php $no=1; ?>

            @foreach($blogs as $blog)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ $blog->title }}</td>
                    <td>{{ $blog->description }}</td>
                    <td>
                        <a href="{{route('blog.edit',$blog->id)}}" ><button><span class="glyphicon glyphicon-refresh"></span></button></a>

                        <form action="{{route('blog.destroy',$blog->id)}}" method="POST">
                            <input type="hidden" name="_method" value="delete">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            
                            <button type="submit"  value="apagar"><span class="glyphicon glyphicon-trash"></span></button>

                        </form>
                    </td>
                </tr>
            @endforeach
        </table>
        {!! $blogs->links() !!}
    </div>
   @stop