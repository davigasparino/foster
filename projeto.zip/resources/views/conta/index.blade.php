@extends('master')
    @section('content')
    <div class="col-md-12">
        <div class="col-md-12">
            <h1>Contass</h1>
            <p>{{ Session::get('alert-success') }}</p>
        </div>
    </div>
    <div class="row">
        <table class="table table-striped">
            <tr>
                <th>No. </th>
                <th>Title </th>
                <th>Description </th>
                <th>Actions</th>
            </tr>

            <a href="{{route('conta.create')}}" class="btn btn-info pull-right">Inserir Registro</a>
            <?php $no=1; ?>

            @foreach($contas as $conta)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ $conta->title }}</td>
                    <td>{{ $conta->description }}</td>
                    <td>
                        <a href="{{route('conta.edit',$conta->id)}}" ><button><span class="glyphicon glyphicon-refresh"></span></button></a>

                        <form action="{{route('conta.destroy',$conta->id)}}" method="POST">
                            <input type="hidden" name="_method" value="delete">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            
                            <button type="submit"  value="apagar"><span class="glyphicon glyphicon-trash"></span></button>

                        </form>
                    </td>
                </tr>
            @endforeach
        </table>
        {!! $contas->links() !!}
    </div>
   @stop