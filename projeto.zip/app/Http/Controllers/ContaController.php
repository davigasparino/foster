<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Conta;

class ContaController extends Controller
{
    private $totalpage = 10;

    public function index()
    {
        //show data
        $contas = Conta::paginate($this->totalpage);
        return view('Conta.index',['contas' => $contas]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('conta.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
           'title'=> 'required',
           'description' => 'required',
        ]);

        $conta = new conta;
        $conta->title = $request->title;
        $conta->description = $request->description;
        $conta->save();
        return redirect()->route('conta.index')->with('alert-success','Inserido com Sucesso');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $conta = Conta::findOrFail($id);
        //retorno da edit views
        return view('conta.edit',compact('conta'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'title'=> 'required',
            'description' => 'required',
        ]);

        $conta = Conta::findOrFail($id);

        $conta->title = $request->title;
        $conta->description = $request->description;
        $conta->save();
        return redirect()->route('conta.index')->with('alert-success', 'Alterado com Sucesso');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $conta = Conta::findOrFail($id);
        $conta->delete();
        return redirect()->route('conta.index')->with('alert-success', 'Deletado com Sucesso');/**/
    }
}
